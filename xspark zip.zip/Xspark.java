import java.util.*;

enum Role {
    ATHLETE, COACH, SUPPORT_STAFF
}

class User {
    String username;
    String password;
    Role role;
    Set<String> completedModules = new HashSet<>();
    int quizScore = 0;

    User(String username, String password, Role role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }
}

class ContentModule {
    String title;
    String content;
    String language;

    ContentModule(String title, String content, String language) {
        this.title = title;
        this.content = content;
        this.language = language;
    }

    void display() {
        System.out.println("Module: " + title);
        System.out.println("Language: " + language);
        System.out.println("Content: " + content);
    }
}

class Quiz {
    String question;
    List<String> options;
    int correctOption;

    Quiz(String question, List<String> options, int correctOption) {
        this.question = question;
        this.options = options;
        this.correctOption = correctOption;
    }

    boolean takeQuiz(Scanner sc) {
        System.out.println("Quiz: " + question);
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ") " + options.get(i));
        }
        System.out.print("Choose option: ");
        int answer = sc.nextInt();
        return answer == correctOption;
    }
}

class Notification {
    static void send(String message, User user) {
        System.out.println("Notification to " + user.username + ": " + message);
    }
}

class AntiDopingPlatform {
    Map<String, User> users = new HashMap<>();
    List<ContentModule> modules = new ArrayList<>();
    List<Quiz> quizzes = new ArrayList<>();

    void register(String username, String password, Role role) {
        users.put(username, new User(username, password, role));
        System.out.println("User registered: " + username + " [" + role + "]");
    }

    User login(String username, String password) {
        User user = users.get(username);
        if (user != null && user.password.equals(password)) {
            System.out.println("Login successful: " +      username);
            return user;
        }
        System.out.println("Login failed.");
        return null;
    }

    void addModule(ContentModule module) {
        modules.add(module);
    }

    void addQuiz(Quiz quiz) {
        quizzes.add(quiz);
    }

    void showModules(User user) {
        for (ContentModule module : modules) {
            module.display();
            user.completedModules.add(module.title);
        }
    }

    void conductQuiz(User user, Scanner sc) {
        int score = 0;
        for (Quiz quiz : quizzes) {
            if (quiz.takeQuiz(sc)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect.");
            }
        }
        user.quizScore = score;
        System.out.println("Quiz Completed. Score: " + score);
    }

    void showAnalytics(User user) {
        System.out.println("Analytics for: " + user.username);
        System.out.println("Modules Completed: " + user.completedModules);
        System.out.println("Quiz Score: " + user.quizScore);
    }
}

public class Main {
    public static void main(String[] args) {
        AntiDopingPlatform platform = new AntiDopingPlatform();
        Scanner sc = new Scanner(System.in);

        platform.addModule(new ContentModule("Introduction to Anti-Doping", "Anti-doping is crucial for fair play...", "English"));
        platform.addModule(new ContentModule("Prohibited Substances", "List of substances banned in sports...", "English"));

        platform.addQuiz(new Quiz("What is WADA?", List.of("A sports brand", "World Anti-Doping Agency", "A drug", "None"), 2));
        platform.addQuiz(new Quiz("Are energy drinks banned?", List.of("Always", "Never", "Sometimes", "Not Sure"), 3));

        platform.register("athlete01", "pass123", Role.ATHLETE);
        platform.register("coach01", "pass456", Role.COACH);

        User user = platform.login("athlete01", "pass123");
        if (user != null) {
            Notification.send("Welcome to Anti-Doping Learning!", user);

            platform.showModules(user);

            platform.conductQuiz(user, sc);

            platform.showAnalytics(user);

            Notification.send("You have completed today's learning session!", user);
        }
    }
}